﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ST10451856_NombuleloShukuma_Part1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //This displays the ASCII logo of the chatbot
            Console.WriteLine(@"
.......................WWWW.......................
......................W0xk0W......................
............WWWWWWWWWWNOooONWWWWWWWWWW............
........WNKOkkkkkkkkkkkdoodkkkkkkkkkkkOKNW........
.......W0xdk00000000000000000000000000kdxKW.......
......WKddKW..........................WKddKW......
WXXW..W0okN............................Xko0W..WXXW
XxxX..W0okN............................Nko0W.WXxxX
KdxX..W0okN....NKO0XW........WX0OKN....Nko0W.WXxdK
KdxX..W0okN...WKdlokN........NkoldKW...Nko0W.WXxdK
KdxXW.W0okN....NKO0XW........WX0OKN....Nko0W.WXxdK
XxxX..W0okN............................Nko0W.WXxxX
WXXW..W0okXW..........................WXko0W..WXXW
......W0odkOOOOOOOOOOOOOOOOOOOOOOOOOOOOkdo0W......
......W0odkOOOOOOOOOOOOOOOOOOOOOOOOOOOOkdo0W......
......W0okNW..........................WNko0W......
......W0dxX............................XxdKW......
.......NkdkKXNNNNNNNWW......WNNNNNNNNXKkdON.......
........NKkxxxxxxxxxx0W....W0xxxxxxxxxxkKN........
..........WNNNXNNNXKxdONWWNOdxKXNNNXXNNW..........
....................NOdxOOxdON....................
.....................W0dood0W.....................
......................WXKKXW......................

.....................Charlamos....................
");
            try
            {
                // The audio greeting to welcome the user                
                string audioPath = @"C:\\Users\\RC_Student_lab\\source\\repos\\ST10451856_NombuleloShukuma_Part1\\Welcoming message.wav";
                SoundPlayer player = new SoundPlayer(audioPath);

                player.Load(); // Loads the message  into memory
                player.Play(); // Play the welcome audio

                Console.WriteLine("Finished playing the welcoming message.");
            }
            catch (Exception ex)
            {
                //Displays the message when it can't play the audio file or find it on the specified location 
                Console.WriteLine("Error playing sound: " + ex.Message); 
            }


            Console.WriteLine("You can press Enter after viewing the logo to continue with the program...");
            Console.ReadLine(); // This allows the user to view the logo before proceeding

            Console.Clear(); //This ensures that the logo clears up and starts the program when the user presses enter


            // Ask for the user's name to personalize the conversation
            Console.WriteLine("Hello. Please enter your name.");
            string userName = Console.ReadLine();
            Console.WriteLine($"Welcome to Cyber Security Bot {userName}, how may I be of help?");

            while (true)
            {

                string response = Console.ReadLine();

                // Simulate the bot "typing" to feel more human and natural
                PauseTypingEffect();


                if (response.ToLower() == "hello")
                {
                    Console.WriteLine($"Hello, {userName}! I'm happy to chat with you. How may i be of help?");
                    Console.ReadLine();
                }
                else if (response.ToLower() == "how are you")
                {
                    Console.WriteLine($"I'm well, thanks for asking {userName}, how may I be of help?");
                    Console.ReadLine();

                }
                else if (response.ToLower() == "What's your purpose?")
                {
                    Console.WriteLine($"I'm glad you asked {userName}, my purpose is to provide information regarding Cyber Security, how to protect yourself online, safe browsing, what is phishing and a whole lot more.");
                    Console.WriteLine("Is there anything else that I can help you with?");
                    Console.ReadLine();
                }
                else if (response.ToLower() == "What can I ask you about?")
                {
                    Console.WriteLine("I am a CyberSecurity chatbot so you can ask me anything related to it. For example: what is Cybersecurity, What can I do to protect myself from cybersecurity threats, and how can i identify cybersecurity threats");
                }

                else if (response.ToLower() == "Bye")
                {
                    Console.WriteLine("Goodbye, it was nice chatting to you, have yourself a lovely day.");
                    break;
                }
                else
                {
                    Console.WriteLine("I'm sorry, I didn't understand that, could you try to rephrase your question.");
                }

            }


             void PauseTypingEffect()
            {
                Console.Write("Charlamos is typing...");
                for (int i = 0; i < 3; i++)
                {
                    Thread.Sleep(500); // This puts a 0.5 second pause effect to have a more human like feel
                    Console.Write(".");
                }
                Console.WriteLine(); // A new line is shown after typing
            }
        }

    }
}